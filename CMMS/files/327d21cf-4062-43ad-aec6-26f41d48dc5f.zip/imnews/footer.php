<?php
/*
با پرداخت کردن هزینه‌ی آماده سازی پوسته می‌توانید پیوند پارسی‌ساز را پاک کنید
https://mandegarweb.com/?p=4519
*/
wp_copy_right(); ?>
</body>
</html>